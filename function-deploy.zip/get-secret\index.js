const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential } = require("@azure/identity");

// Cache for secrets (5 minute TTL)
const secretCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

module.exports = async function (context, req) {
    context.log('🔐 Secret retrieval request received');
    
    // Set CORS headers
    context.res = {
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Content-Type": "application/json"
        }
    };

    // Handle preflight OPTIONS request
    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        context.log('🔍 Starting secret retrieval process');
        
        const { secretName } = req.body || {};
        context.log(`📝 Secret name requested: ${secretName}`);
        
        if (!secretName) {
            context.log('❌ No secret name provided');
            context.res.status = 400;
            context.res.body = JSON.stringify({
                error: "secretName is required"
            });
            return;
        }

        // Validate allowed secret names for security
        const allowedSecrets = [
            'supabase-url',
            'supabase-anon-key',
            'supabase-password',
            'openai-direct-api-key'
        ];

        if (!allowedSecrets.includes(secretName)) {
            context.log(`❌ Unauthorized secret request: ${secretName}`);
            context.res.status = 403;
            context.res.body = JSON.stringify({
                error: "Access to this secret is not allowed"
            });
            return;
        }

        // Check cache first
        const cacheKey = secretName;
        const cached = secretCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
            context.log(`🔄 Using cached secret: ${secretName}`);
            context.res.body = JSON.stringify({
                value: cached.value
            });
            return;
        }

        // Try to load Azure dependencies with detailed error handling
        context.log('🔑 Loading Azure SDK...');
        let SecretClient, DefaultAzureCredential;
        
        try {
            const keyvaultModule = require("@azure/keyvault-secrets");
            const identityModule = require("@azure/identity");
            
            SecretClient = keyvaultModule.SecretClient;
            DefaultAzureCredential = identityModule.DefaultAzureCredential;
            
            context.log('✅ Azure SDK modules loaded successfully');
        } catch (importError) {
            context.log(`❌ Failed to load Azure SDK: ${importError.message}`);
            context.res.status = 500;
            context.res.body = JSON.stringify({
                error: "Azure SDK not available",
                details: importError.message,
                suggestion: "Dependencies may not be installed. Check Function App deployment."
            });
            return;
        }

        // Initialize Azure credentials
        context.log('🔑 Initializing Azure credentials...');
        const credential = new DefaultAzureCredential();
        
        context.log('🔐 Creating Key Vault client...');
        const keyVaultUrl = process.env.KEY_VAULT_URL || "https://perfectzenkai-secrets.vault.azure.net/";
        const keyVaultClient = new SecretClient(keyVaultUrl, credential);

        // Fetch from Key Vault
        context.log(`🔍 Fetching secret from Key Vault: ${secretName}`);
        const secret = await keyVaultClient.getSecret(secretName);

        if (!secret.value) {
            context.log(`❌ Secret ${secretName} has no value`);
            context.res.status = 404;
            context.res.body = JSON.stringify({
                error: "Secret not found or has no value"
            });
            return;
        }

        // Cache the secret
        secretCache.set(cacheKey, {
            value: secret.value,
            timestamp: Date.now()
        });

        context.log(`✅ Successfully retrieved secret: ${secretName}`);
        context.res.body = JSON.stringify({
            value: secret.value
        });

    } catch (error) {
        context.log(`❌ Error retrieving secret: ${error.message}`);
        context.log(`❌ Error stack: ${error.stack}`);
        context.log(`❌ Error name: ${error.name}`);
        context.log(`❌ Error code: ${error.code}`);
        
        context.res.status = 500;
        context.res.body = JSON.stringify({
            error: "Failed to retrieve secret",
            details: error.message,
            errorName: error.name,
            errorCode: error.code,
            timestamp: new Date().toISOString()
        });
    }
}; 