const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential, ManagedIdentityCredential } = require("@azure/identity");

// Cache for secrets (5 minute TTL)
const secretCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * ENHANCED: Creates a Key Vault client with the appropriate credential and fallback strategy.
 * @param {object} context - The Azure Function context for logging.
 * @returns {SecretClient|null} An instance of the Key Vault SecretClient or null if fallback should be used.
 */
function createKeyVaultClient(context) {
    try {
        let credential;
        const keyVaultUrl = process.env.KEYVAULT_URL || "https://perfectzenkai-secrets.vault.azure.net/";

        // Enhanced: Check for environment variable fallback first
        if (process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY) {
            context.log('🔄 Environment variables detected - will use as fallback if Key Vault fails');
        }

        // WEBSITE_INSTANCE_ID is a reliable indicator of running in an Azure App Service.
        if (process.env.WEBSITE_INSTANCE_ID) {
            context.log('🔑 Running in Azure. Using Managed Identity Credential.');
            context.log(`🔍 Azure instance ID: ${process.env.WEBSITE_INSTANCE_ID}`);
            credential = new ManagedIdentityCredential();
        } else {
            context.log('🔑 Running locally. Using Default Azure Credential.');
            credential = new DefaultAzureCredential();
        }
        
        context.log(`🔐 Creating Key Vault client for: ${keyVaultUrl}`);
        return new SecretClient(keyVaultUrl, credential);
    } catch (error) {
        context.log(`❌ Failed to create Key Vault client: ${error.message}`);
        return null;
    }
}

/**
 * ENHANCED: Fallback to environment variables if Key Vault is unavailable
 */
function getSecretFromEnvironment(secretName, context) {
    const envMap = {
        'supabase-url': process.env.SUPABASE_URL,
        'supabase-anon-key': process.env.SUPABASE_ANON_KEY
    };

    const envValue = envMap[secretName];
    if (envValue) {
        context.log(`✅ Retrieved ${secretName} from environment variables`);
        return envValue;
    }

    context.log(`❌ ${secretName} not found in environment variables`);
    return null;
}

module.exports = async function (context, req) {
    context.log('🔐 Secret retrieval request received');
    context.log(`🔍 Environment check - WEBSITE_INSTANCE_ID: ${process.env.WEBSITE_INSTANCE_ID || 'undefined'}`);
    context.log(`🔍 Environment check - KEYVAULT_URL: ${process.env.KEYVAULT_URL || 'using default'}`);
    
    // Set CORS headers
    context.res = {
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Content-Type": "application/json"
        }
    };

    // Handle preflight OPTIONS request
    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        context.log('🔍 Starting secret retrieval process');
        
        const { secretName } = req.body || {};
        context.log(`📝 Secret name requested: ${secretName}`);
        
        if (!secretName) {
            context.log('❌ No secret name provided');
            context.res.status = 400;
            context.res.body = JSON.stringify({
                error: "secretName is required"
            });
            return;
        }

        // Validate allowed secret names for security
        const allowedSecrets = [
            'supabase-url',
            'supabase-anon-key',
            'supabase-password',
            'openai-direct-api-key'
        ];

        if (!allowedSecrets.includes(secretName)) {
            context.log(`❌ Unauthorized secret request: ${secretName}`);
            context.res.status = 403;
            context.res.body = JSON.stringify({
                error: "Access to this secret is not allowed"
            });
            return;
        }

        // Check cache first
        const cacheKey = secretName;
        const cached = secretCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
            context.log(`🔄 Using cached secret: ${secretName}`);
            context.res.body = JSON.stringify({
                value: cached.value
            });
            return;
        }

        // Try Key Vault first
        const keyVaultClient = createKeyVaultClient(context);
        let secretValue = null;

        if (keyVaultClient) {
            try {
                // Fetch from Key Vault with timeout
                context.log(`🔍 Fetching secret from Key Vault: ${secretName}`);
                
                const secretPromise = keyVaultClient.getSecret(secretName);
                const timeoutPromise = new Promise((_, reject) => 
                    setTimeout(() => reject(new Error('Key Vault operation timeout')), 15000)
                );
                
                const secret = await Promise.race([secretPromise, timeoutPromise]);

                if (secret && secret.value) {
                    secretValue = secret.value;
                    context.log(`✅ Successfully retrieved secret from Key Vault: ${secretName}`);
                }
            } catch (kvError) {
                context.log(`⚠️ Key Vault failed: ${kvError.message}`);
                context.log(`⚠️ Key Vault error details: ${JSON.stringify({
                    name: kvError.name,
                    code: kvError.code,
                    statusCode: kvError.statusCode
                })}`);
            }
        }

        // Fallback to environment variables if Key Vault failed
        if (!secretValue) {
            context.log(`🔄 Attempting environment variable fallback for: ${secretName}`);
            secretValue = getSecretFromEnvironment(secretName, context);
        }

        if (!secretValue) {
            context.log(`❌ Secret ${secretName} not found in Key Vault or environment variables`);
            context.res.status = 404;
            context.res.body = JSON.stringify({
                error: "Secret not found in any available source",
                sources_tried: ["key_vault", "environment_variables"]
            });
            return;
        }

        // Cache the secret
        secretCache.set(cacheKey, {
            value: secretValue,
            timestamp: Date.now()
        });

        context.log(`✅ Successfully retrieved secret: ${secretName}`);
        context.res.body = JSON.stringify({
            value: secretValue
        });

    } catch (error) {
        context.log(`❌ Error retrieving secret: ${error.message}`);
        context.log(`❌ Error stack: ${error.stack}`);
        context.log(`❌ Error name: ${error.name}`);
        context.log(`❌ Error code: ${error.code}`);
        
        // Provide more specific error messages
        let errorMessage = "Failed to retrieve secret";
        if (error.message.includes('timeout')) {
            errorMessage = "Key Vault operation timed out";
        } else if (error.message.includes('authentication')) {
            errorMessage = "Authentication failed - check managed identity permissions";
        } else if (error.message.includes('network') || error.message.includes('ENOTFOUND')) {
            errorMessage = "Network error connecting to Key Vault";
        }
        
        context.res.status = 500;
        context.res.body = JSON.stringify({
            error: errorMessage,
            details: error.message,
            errorName: error.name,
            errorCode: error.code,
            timestamp: new Date().toISOString(),
            fallback_available: !!(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY)
        });
        return;
    }
}; 