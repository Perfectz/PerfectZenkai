const { SecretClient } = require("@azure/keyvault-secrets");
const { DefaultAzureCredential, ManagedIdentityCredential } = require("@azure/identity");

// Cache for secrets (5 minute TTL)
const secretCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * REFACTOR: Creates a Key Vault client with the appropriate credential.
 * @param {object} context - The Azure Function context for logging.
 * @returns {SecretClient} An instance of the Key Vault SecretClient.
 */
function createKeyVaultClient(context) {
    let credential;
    const keyVaultUrl = process.env.KEYVAULT_URL || "https://perfectzenkai-secrets.vault.azure.net/";

    // WEBSITE_INSTANCE_ID is a reliable indicator of running in an Azure App Service.
    if (process.env.WEBSITE_INSTANCE_ID) {
        context.log('🔑 Running in Azure. Using Managed Identity Credential.');
        credential = new ManagedIdentityCredential();
    } else {
        context.log('🔑 Running locally. Using Default Azure Credential.');
        credential = new DefaultAzureCredential();
    }
    
    context.log(`🔐 Creating Key Vault client for: ${keyVaultUrl}`);
    return new SecretClient(keyVaultUrl, credential);
}

module.exports = async function (context, req) {
    context.log('🔐 Secret retrieval request received');
    
    // Set CORS headers
    context.res = {
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
            "Content-Type": "application/json"
        }
    };

    // Handle preflight OPTIONS request
    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        context.log('🔍 Starting secret retrieval process');
        
        const { secretName } = req.body || {};
        context.log(`📝 Secret name requested: ${secretName}`);
        
        if (!secretName) {
            context.log('❌ No secret name provided');
            context.res.status = 400;
            context.res.body = JSON.stringify({
                error: "secretName is required"
            });
            return;
        }

        // Validate allowed secret names for security
        const allowedSecrets = [
            'supabase-url',
            'supabase-anon-key',
            'supabase-password',
            'openai-direct-api-key'
        ];

        if (!allowedSecrets.includes(secretName)) {
            context.log(`❌ Unauthorized secret request: ${secretName}`);
            context.res.status = 403;
            context.res.body = JSON.stringify({
                error: "Access to this secret is not allowed"
            });
            return;
        }

        // Check cache first
        const cacheKey = secretName;
        const cached = secretCache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
            context.log(`🔄 Using cached secret: ${secretName}`);
            context.res.body = JSON.stringify({
                value: cached.value
            });
            return;
        }

        // Use the factory to create the client
        const keyVaultClient = createKeyVaultClient(context);

        // Fetch from Key Vault with timeout
        context.log(`🔍 Fetching secret from Key Vault: ${secretName}`);
        
        // Add timeout to the Key Vault operation
        const secretPromise = keyVaultClient.getSecret(secretName);
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Key Vault operation timeout')), 15000)
        );
        
        const secret = await Promise.race([secretPromise, timeoutPromise]);

        if (!secret || !secret.value) {
            context.log(`❌ Secret ${secretName} has no value`);
            context.res.status = 404;
            context.res.body = JSON.stringify({
                error: "Secret not found or has no value"
            });
            return;
        }

        // Cache the secret
        secretCache.set(cacheKey, {
            value: secret.value,
            timestamp: Date.now()
        });

        context.log(`✅ Successfully retrieved secret: ${secretName}`);
        context.res.body = JSON.stringify({
            value: secret.value
        });

    } catch (error) {
        context.log(`❌ Error retrieving secret: ${error.message}`);
        context.log(`❌ Error stack: ${error.stack}`);
        context.log(`❌ Error name: ${error.name}`);
        context.log(`❌ Error code: ${error.code}`);
        
        // Provide more specific error messages
        let errorMessage = "Failed to retrieve secret";
        if (error.message.includes('timeout')) {
            errorMessage = "Key Vault operation timed out";
        } else if (error.message.includes('authentication')) {
            errorMessage = "Authentication failed - check managed identity permissions";
        } else if (error.message.includes('network') || error.message.includes('ENOTFOUND')) {
            errorMessage = "Network error connecting to Key Vault";
        }
        
        context.res.status = 500;
        context.res.body = JSON.stringify({
            error: errorMessage,
            details: error.message,
            errorName: error.name,
            errorCode: error.code,
            timestamp: new Date().toISOString()
        });
        return;
    }
}; 